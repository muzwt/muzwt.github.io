// ── Your links — replace these with your actual URLs ──
const links = {
    tg:     'https://t.me/YOUR_TELEGRAM',
    gh:     'https://github.com/YOUR_GITHUB',
    dc:     'https://discord.com/users/YOUR_DISCORD_ID',
    donate: 'https://YOUR_DONATE_LINK',
};

function openLink(key) {
    if (links[key]) window.open(links[key], '_blank');
}

function start() {
    const overlay = document.getElementById('overlay');
    const video   = document.getElementById('videoBG');
    const card    = document.getElementById('profile-container');

    overlay.classList.add('hidden');

    // Try to play background video if one exists
    video.play().then(() => {
        video.classList.add('playing');
    }).catch(() => {
        // No video or autoplay blocked — that's fine, gradient bg shows
    });

    // Animate card in
    setTimeout(() => {
        card.classList.add('visible');
    }, 100);
}
