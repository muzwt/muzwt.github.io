# muzwt.github.io

## Setup

1. Put your profile picture at `src/img/pfp.jpg`
2. (Optional) Put your background video at `src/video/bg.mp4`
3. Open `src/script.js` and replace the placeholder URLs with your real links
4. Update the description in `index.html` inside the `<p id="description">` tag

## File Structure

```
├── index.html
└── src/
    ├── styles.css
    ├── script.js
    ├── img/
    │   └── pfp.jpg        ← your profile picture
    └── video/
        └── bg.mp4         ← your background video (optional)
```
